<?php
/**
 * @package discuss
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/disboardusergroup.class.php');
/**
 * @package discuss
 * @subpackage mysql
 */
class disBoardUserGroup_mysql extends disBoardUserGroup {}