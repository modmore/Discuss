<?php
/**
 * @package discuss
 */
$xpdo_meta_map = array (
  'disThread' => 
  array (
    0 => 'disThreadDiscussion',
    1 => 'disThreadQuestion',
  ),
);