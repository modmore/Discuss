<?php
/**
 * @package discuss
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/disthreadread.class.php');
/**
 * @package discuss
 * @subpackage mysql
 */
class disThreadRead_mysql extends disThreadRead {}