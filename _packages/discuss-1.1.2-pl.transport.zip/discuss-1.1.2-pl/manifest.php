<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
3PC: Discuss
--------------------
Version: 0.1
Since: December 16th, 2009
Author: Shaun McCormick <shaun@collabpad.com>

A native, threaded forum solution for MODx Revolution.

This is an alpha prerelease. Therefore, things might break. But have fun. :)

Feel free to suggest ideas/improvements/bugs on the forums. 
Also, please see the JIRA project: http://svn.modxcms.com/jira/browse/DISCUSS',
    'changelog' => 'Changelog for Discuss.

- Add ability to bypass stripping remaining bbcode in disPost.getContent
- Fix viewing stats due to changed session place in earlier version.
- Improve performance of disSession GC
- Get rid of MODX.com analytics code in default theme.
- Fix XSS in the search controller (date_start, date_end).
- Fix XSS in the page variable.
- Increase size of disPost.message field to mediumtext.
- Merge in various updates primarily related to search and solr.

Discuss 1.1.1, December 28, 2012
====================================
- #9350 Add missing javascript link for $lAB in default theme
- #9349 Fix errors in build

Discuss 1.1.0, December 24, 2012
====================================
- #7648 Fix certain topic replies and possible XSS hole.
- #5742 Fix post page calculations
- Add thread pagination in board view
- Add option to sort answer first in Q&A threads; default to false.
- Add new user/posts view
- #5625 Fix issue with board feed and absolute urls
- #6544 Fix deleting of messages also deleting replies to that message.
- Add settings to control date cutoff for no_replies and unanswered_questions views.
- Add new discuss.debug_templates setting to throw in HTML comments for every loaded tpl chunk.
- #4768 Ask user to login if thread not found to allow links to private forums to work through login
- Enable statistics globally (can be disabled in the manifest) so we can use it everywhere.
- Fix url generation on notification emails.
- Add new discuss.user.new_replies and discuss.user.unread_posts placeholders
- #6584 Fix fatal error on messages/view and improve session place behavior for messages
- Add ability to customize separator between subboards through theme\'s manifest.php
- Fix overridden disUser.toArray and add posts_formatted placeholder.
- Ensure action buttons have specific and consistent class names for styling (dis-action-name_of_action)
- Make length of post excerpt configurable.
- Fix bug in mgr processor board/getnodes causing issues in CMP.
- Add ability to discussLogin post login hook to redirect back to prior location based on sessionPlace
- Update sessionPlace to include page number on boards, threads.
- Refactor disBoard.getLastPostTitle to disBoard.getLastPostTitleSlug

Discuss 1.0.0
====================================
- Add Thread types
- Lots of feature adds, flat-board capable only at this time
- Not backwards-compatible with Discuss 0.1

Discuss 0.1
====================================
- Added bg translation
- Added ability to modify attachments on a post when modifying post in FE
- Fixed breadcrumbs, board displays, etc
- Added OnDiscussPostSave, OnDiscussPostBeforeSave, OnDiscussPostFetchContent system events
- Added editedon support to posts
- Added download attachment support
- Added icons for board/category in mgr tree
- Enabled coloring of usernames based on usergroup
- i18n of mgr processors and JS
- Random bugfixes, optimizations, code tweaks
- Fixed bugs with URL generation
- Added discuss.reserved_usernames setting
- Fixed bugs in install resolvers
- Added in missing DiscussRecentPosts properties to build
- Fixed table schema to allow for dynamic table prefix, allowing for multiple forums per DB
- Fixed disPost::getViewing
- Lots of fixes to Registration, security
- Fixes to CSS / layouts to work more properly within an existing design
- Got setup and build working as expected
- Lots of i18n work
- Added auto-install Resources resolver and setup option 
- Started build script process, i18n work
- Initial changelog started
',
    'setup-options' => 'discuss-1.1.2-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1592570202fefef09526d59f2b9ae68a',
      'native_key' => 'discuss',
      'filename' => 'modNamespace/4184160b585583615c1bb237ebfdee85.vehicle',
      'namespace' => 'discuss',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f7fa36388a25bb54bb55ddae96765c0a',
      'native_key' => 1,
      'filename' => 'modCategory/41d4d430640e5de5e0978d407e42e8be.vehicle',
      'namespace' => 'discuss',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6d123ecec56521f4773fee4e1c6a75cb',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/c22bd88054598200eb41bc27d2c9b19b.vehicle',
      'namespace' => 'discuss',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '941c3f8e4e170f9254f8169de3ec0416',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/808b4756cb6519dbc4ebe0b348a5c3f4.vehicle',
      'namespace' => 'discuss',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd95bdeb93a2c7d27bae1b2ad31dc8e52',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/954151cbe91ddccc73403aee667420f4.vehicle',
      'namespace' => 'discuss',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '25b3faf9f8c2e8826abcda68639dfd5d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/54f008a90ccf2626778ae9e77339fda9.vehicle',
      'namespace' => 'discuss',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '872a1601e3c8bc8c7fd9dec0ece4b131',
      'native_key' => 'discuss.admin_email',
      'filename' => 'modSystemSetting/b3b4993cf7b95e493d046be7ca8cfec5.vehicle',
      'namespace' => 'discuss',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8251aa55899c66d40e2a1217f24f0b5',
      'native_key' => 'discuss.admin_groups',
      'filename' => 'modSystemSetting/c9ad35bad4c9a6fadec3c725f34d8336.vehicle',
      'namespace' => 'discuss',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06588bed403f374ce87b53931ec9fe48',
      'native_key' => 'discuss.allow_custom_titles',
      'filename' => 'modSystemSetting/d7a6056d1bf1b9f4e26db9480c5e01d1.vehicle',
      'namespace' => 'discuss',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6b41300b3e32bd33923bc120f4493bb',
      'native_key' => 'discuss.allow_guests',
      'filename' => 'modSystemSetting/221ac82b62bad460026cabcad87c14b0.vehicle',
      'namespace' => 'discuss',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9917e8e0e2f125127d4403e50f7c2e6',
      'native_key' => 'discuss.archive_threads_after',
      'filename' => 'modSystemSetting/dd94e45cae3e955ab4304ac83f419094.vehicle',
      'namespace' => 'discuss',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e577716b4c53708d83ca540cec36192',
      'native_key' => 'discuss.attachments_allowed_filetypes',
      'filename' => 'modSystemSetting/37a5432911967bdb5c6649b54524f99a.vehicle',
      'namespace' => 'discuss',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a359a4cc7060e006c32ae7bdb59a8af',
      'native_key' => 'discuss.attachments_max_filesize',
      'filename' => 'modSystemSetting/ddb46b964ca04895f8ca47879a9d7134.vehicle',
      'namespace' => 'discuss',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3505f88fe0852b38e3392a51dd9af1e8',
      'native_key' => 'discuss.attachments_max_per_post',
      'filename' => 'modSystemSetting/67cd67e3fb4d90934eba8e52e43dea16.vehicle',
      'namespace' => 'discuss',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e240ee404c21bed76a65aec928e8e02a',
      'native_key' => 'discuss.attachments_path',
      'filename' => 'modSystemSetting/d730837f9ff07d0816cf9befba0275e6.vehicle',
      'namespace' => 'discuss',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '94f4aa8a9dd1c9b1e0fb36c8f69fb139',
      'native_key' => 'discuss.attachments_url',
      'filename' => 'modSystemSetting/594cee4f61a5ca262e9cc4d692b68462.vehicle',
      'namespace' => 'discuss',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9102469c793b4537e47fa4e708eb82b',
      'native_key' => 'discuss.bad_words',
      'filename' => 'modSystemSetting/b589e125e2202863c7fe0509b5e41d0f.vehicle',
      'namespace' => 'discuss',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2737525054d948852c274b44a3f961bb',
      'native_key' => 'discuss.bad_words_replace',
      'filename' => 'modSystemSetting/0ee52be809a29ad5f521ea51dac578c3.vehicle',
      'namespace' => 'discuss',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b845b7e7a3e3db884613a08d9c7da74',
      'native_key' => 'discuss.bad_words_replace_string',
      'filename' => 'modSystemSetting/bada057eff1a5bd28d4eb084e609664f.vehicle',
      'namespace' => 'discuss',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24e729717b183866311224ca08a19cba',
      'native_key' => 'discuss.bbcode_enabled',
      'filename' => 'modSystemSetting/0c711f0bead25b51ff019b4afb41189c.vehicle',
      'namespace' => 'discuss',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7aafc196e9678f380da2f347379ffd71',
      'native_key' => 'discuss.default_board_moderators',
      'filename' => 'modSystemSetting/6abf313da70632e5a56ea1c55d22d1bc.vehicle',
      'namespace' => 'discuss',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4825c50a901309b0b436c26282fa185d',
      'native_key' => 'discuss.default_board_usergroups',
      'filename' => 'modSystemSetting/c6d59a319c058e3a1aca9aed1ee8183b.vehicle',
      'namespace' => 'discuss',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03108710be462c92aefaed348f011f65',
      'native_key' => 'discuss.email_reported_post_subject',
      'filename' => 'modSystemSetting/380b4942721e25a382309e21f28034a8.vehicle',
      'namespace' => 'discuss',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87182a4290fce585bc25fbe9eca500a7',
      'native_key' => 'discuss.email_reported_post_chunk',
      'filename' => 'modSystemSetting/24322dc1bb8c11031fcaca36b05b4f26.vehicle',
      'namespace' => 'discuss',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e717661b42e54a0bcd47d682d9dfb043',
      'native_key' => 'discuss.theme',
      'filename' => 'modSystemSetting/612281ac345bb16a38309d7b4d1d6c12.vehicle',
      'namespace' => 'discuss',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d5a2e30494e6c9052f557b78457f412',
      'native_key' => 'discuss.post_per_page',
      'filename' => 'modSystemSetting/b142e042cab76c99890d36e03b56e9bd.vehicle',
      'namespace' => 'discuss',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4727c4bac168747fd49d5757d5b45bd9',
      'native_key' => 'discuss.use_custom_post_parser',
      'filename' => 'modSystemSetting/cc45facbcdcd01fc6833b1a1a77f10e9.vehicle',
      'namespace' => 'discuss',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f13c699fafe9ff764edbd10e9352d66a',
      'native_key' => 'discuss.courtesy_edit_wait',
      'filename' => 'modSystemSetting/3ee08e24b461003a551491cf486300db.vehicle',
      'namespace' => 'discuss',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52656993bd9c7b3db735b7f7ab28e6f7',
      'native_key' => 'discuss.date_format',
      'filename' => 'modSystemSetting/c2921ff26b27afdc34ca8411d25d2bdd.vehicle',
      'namespace' => 'discuss',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e8c94f9da8cbc6919f132f8da17de5b',
      'native_key' => 'discuss.debug',
      'filename' => 'modSystemSetting/d84e9a538a1b9a7462b8e03d172163a4.vehicle',
      'namespace' => 'discuss',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee036a059a5f0b1eaefccc7a1e032996',
      'native_key' => 'discuss.debug_templates',
      'filename' => 'modSystemSetting/b72a605db468d4911963ae74233b9088.vehicle',
      'namespace' => 'discuss',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4650e44747969f71b8a6c8cfcedc76e1',
      'native_key' => 'discuss.enable_hot',
      'filename' => 'modSystemSetting/b62bdb0d364f301832ffe59be305926b.vehicle',
      'namespace' => 'discuss',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1e264a6874b958eaf54e24beb872b1c',
      'native_key' => 'discuss.enable_notifications',
      'filename' => 'modSystemSetting/041d48d14217890aff80d2d15aa8b976.vehicle',
      'namespace' => 'discuss',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e405c81a5fd7cd5d9aa47e5900fef6f',
      'native_key' => 'discuss.enable_sticky',
      'filename' => 'modSystemSetting/d21f4d7d336413f50674ad1c6234e3ae.vehicle',
      'namespace' => 'discuss',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd05102a785270c6e369738d39caafa53',
      'native_key' => 'discuss.forum_title',
      'filename' => 'modSystemSetting/5d3f8a10af113b8ae3ef6fdc16a77819.vehicle',
      'namespace' => 'discuss',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99d95a16992a06721622ee3a04870031',
      'native_key' => 'discuss.global_moderators',
      'filename' => 'modSystemSetting/9427e1e6ae72cd70321b09225cca6ded.vehicle',
      'namespace' => 'discuss',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc3bd93692ea09ea89f70953aa2e91d3',
      'native_key' => 'discuss.hot_thread_threshold',
      'filename' => 'modSystemSetting/05d5009d03ce6ca10d346b7120f2df01.vehicle',
      'namespace' => 'discuss',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c6d8cd240d0fce1dbad14f4dfd3dd36',
      'native_key' => 'discuss.max_post_depth',
      'filename' => 'modSystemSetting/0c5479e573d66aa8cbe44edca7c7f2a6.vehicle',
      'namespace' => 'discuss',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '176fe3adf43cce542f10a3397a7fc555',
      'native_key' => 'discuss.max_signature_length',
      'filename' => 'modSystemSetting/2b764a44d4ce88771ff0aa36ae119153.vehicle',
      'namespace' => 'discuss',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7bbae9263e7a617c34d88d06e14262f',
      'native_key' => 'discuss.maximum_post_size',
      'filename' => 'modSystemSetting/2ff68162f4ef551ffb03d1be5a46d489.vehicle',
      'namespace' => 'discuss',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '338566ff87f0a69bf01e7611a3784204',
      'native_key' => 'discuss.new_replies_threshold',
      'filename' => 'modSystemSetting/9e2d4cee38475d8d392fcc2ab8c956ec.vehicle',
      'namespace' => 'discuss',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd33a2e3afa55968b8bbf2e4928fdc95c',
      'native_key' => 'discuss.unanswered_questions_threshold',
      'filename' => 'modSystemSetting/73c0c5d564846c0aa714150baddd6ae4.vehicle',
      'namespace' => 'discuss',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c980e111ecba7df0d76e01e4f0f9db07',
      'native_key' => 'discuss.no_replies_threshold',
      'filename' => 'modSystemSetting/4195c7af336055adbc32cfd88f99c1bb.vehicle',
      'namespace' => 'discuss',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f2aa1cd7e1c1394f79066338b8be9aa',
      'native_key' => 'discuss.recent_threshold_days',
      'filename' => 'modSystemSetting/4ad87b8e5b8cd8459ef47f7e7c72f44d.vehicle',
      'namespace' => 'discuss',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ababc32a62b0545e3c16697b8486bd44',
      'native_key' => 'discuss.notification_new_post_subject',
      'filename' => 'modSystemSetting/22096784af3a6ef24ca8b5eb80bfc90c.vehicle',
      'namespace' => 'discuss',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3be87586291754e0a0771214b38e7212',
      'native_key' => 'discuss.notification_new_post_chunk',
      'filename' => 'modSystemSetting/c8256d988ff30ceadcb66b16cdeaa8a2.vehicle',
      'namespace' => 'discuss',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0fd1760b125f0299211d33178a4dcf42',
      'native_key' => 'discuss.num_recent_posts',
      'filename' => 'modSystemSetting/bd785dfeb30ca24799c74631b462be9b.vehicle',
      'namespace' => 'discuss',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6bae7e6529b2eddc2df802250c6bb7f9',
      'native_key' => 'discuss.page_param',
      'filename' => 'modSystemSetting/603581bf0447e9295a5a1178739e16cd.vehicle',
      'namespace' => 'discuss',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c18d1c0de3cf94d9e90dce8e63feae15',
      'native_key' => 'discuss.parser_class',
      'filename' => 'modSystemSetting/8e1186ec1fddaf3bf6e22f0f124926b9.vehicle',
      'namespace' => 'discuss',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b22c451d6f18123ee8b5f65bae8a2ce6',
      'native_key' => 'discuss.parser_class_path',
      'filename' => 'modSystemSetting/73abad5de029acdc674dc5c1be5bf199.vehicle',
      'namespace' => 'discuss',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ee5cb0a2f487747138856a08ebecc3a',
      'native_key' => 'discuss.post_sort_dir',
      'filename' => 'modSystemSetting/79c4366d0c1efe98f214843e66d054b9.vehicle',
      'namespace' => 'discuss',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '267024f78c8fc748ca3b9dd336f0b759',
      'native_key' => 'discuss.recycle_bin_board',
      'filename' => 'modSystemSetting/cb7166b13ec8756eae7f95b0b227d496.vehicle',
      'namespace' => 'discuss',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab852a407ea4acbba99e9dfef172cc09',
      'native_key' => 'discuss.show_whos_online',
      'filename' => 'modSystemSetting/bc178de981dc82b575d083dd8daff2c1.vehicle',
      'namespace' => 'discuss',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e94fab0f17797ecb009044ca962302a9',
      'native_key' => 'discuss.spam_bucket_board',
      'filename' => 'modSystemSetting/5dffc87526cdd379670ae4987975d129.vehicle',
      'namespace' => 'discuss',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86bf52f341ed38e68b4260636c9c92fa',
      'native_key' => 'discuss.stats_enabled',
      'filename' => 'modSystemSetting/16b3b1ff64b88dc6d3bab996b56e53f4.vehicle',
      'namespace' => 'discuss',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a718869be64bac83b1faef3c2237667e',
      'native_key' => 'discuss.threads_per_page',
      'filename' => 'modSystemSetting/6c9f1e1b5afbb4980f5b777d76c77bdf.vehicle',
      'namespace' => 'discuss',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2832c5e68feaf1bc0c62141be4a504d2',
      'native_key' => 'discuss.user_active_threshold',
      'filename' => 'modSystemSetting/6957b2bdc7177859b336483b88539375.vehicle',
      'namespace' => 'discuss',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4687029eb58d16f9dbebf44f0bbc6c74',
      'native_key' => 'discuss.login_resource_id',
      'filename' => 'modSystemSetting/7c8beebc019eeee158f75c973c7f6068.vehicle',
      'namespace' => 'discuss',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b03dce59f49474dee5d62e479a03391',
      'native_key' => 'discuss.register_resource_id',
      'filename' => 'modSystemSetting/05190e70f754bdce2a13925fba11031a.vehicle',
      'namespace' => 'discuss',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c622903b62842ad7844acbf4844f0b05',
      'native_key' => 'discuss.update_profile_resource_id',
      'filename' => 'modSystemSetting/4c819043553dc005792eb4a5b1e5865f.vehicle',
      'namespace' => 'discuss',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f91855dfdc0caf280b7f36702be12ee',
      'native_key' => 'discuss.forums_resource_id',
      'filename' => 'modSystemSetting/e6a7aacddca167d28d489b98752e4c7e.vehicle',
      'namespace' => 'discuss',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8604eeab93e37e68e6884f5d8b0f3a0',
      'native_key' => 'discuss.sso_mode',
      'filename' => 'modSystemSetting/c66cf0a34377d3a8dc0cb944bdf9282c.vehicle',
      'namespace' => 'discuss',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '564c8adb9344d05a19b92be0d5df5b09',
      'native_key' => 'discuss.gravatar_url',
      'filename' => 'modSystemSetting/650b3e69372490029643b2544c4ffafe.vehicle',
      'namespace' => 'discuss',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7847aa2827db58567ff79e277a6163ad',
      'native_key' => 'discuss.gravatar_default',
      'filename' => 'modSystemSetting/a0cb9b592314cd123babd1e7ed3823a0.vehicle',
      'namespace' => 'discuss',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bf1d4a7ccf8ef98553b789558d842197',
      'native_key' => 'discuss.gravatar_rating',
      'filename' => 'modSystemSetting/f1892dce33cb5d7e681534cf7f357ed5.vehicle',
      'namespace' => 'discuss',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93148b855681309d03b6fa205e4e03fa',
      'native_key' => 'discuss.search_class',
      'filename' => 'modSystemSetting/1c4d6158c0cecadc7b9303ba4234c276.vehicle',
      'namespace' => 'discuss',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7558733ebdad4ec8387bd45038e99271',
      'native_key' => 'discuss.search_class_path',
      'filename' => 'modSystemSetting/57521e4d7548d26aee42d0d05118d850.vehicle',
      'namespace' => 'discuss',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ce31cc447123d02229af1e11a787173',
      'native_key' => 'discuss.solr.hostname',
      'filename' => 'modSystemSetting/6b04f55a883223a42a6b3aef9b71bf55.vehicle',
      'namespace' => 'discuss',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd55b3e95560ffe7dd8768370302bed98',
      'native_key' => 'discuss.solr.port',
      'filename' => 'modSystemSetting/78ca73ec1a9e193bdb655bc7c9326a23.vehicle',
      'namespace' => 'discuss',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '28556068f85ff82a8283a589dcce73ca',
      'native_key' => 'discuss.solr.path',
      'filename' => 'modSystemSetting/470e456f3c91dd25b16b8f3775f0727d.vehicle',
      'namespace' => 'discuss',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '628e1064fc2ede20a75da17b446a7a04',
      'native_key' => 'discuss.solr.username',
      'filename' => 'modSystemSetting/8e612fbdddb87133a7678c2ec79320cc.vehicle',
      'namespace' => 'discuss',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c58dcb34eca7b738fa0b3aad3d7a4190',
      'native_key' => 'discuss.solr.password',
      'filename' => 'modSystemSetting/5bade964fe5f9e1fb33142274b952e90.vehicle',
      'namespace' => 'discuss',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d6ef93506e45cf4628b2c0cae73e817',
      'native_key' => 'discuss.solr.',
      'filename' => 'modSystemSetting/4f21a803d0b0301e77771a92b7990609.vehicle',
      'namespace' => 'discuss',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f560893869e8bed02e90cae159376731',
      'native_key' => 'discuss.solr.ssl',
      'filename' => 'modSystemSetting/61093693fc82d2a8e120ff69b8914f46.vehicle',
      'namespace' => 'discuss',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffb69d3842d85403c16600c4876979a7',
      'native_key' => 'discuss.solr.ssl_cert',
      'filename' => 'modSystemSetting/3882476d80a476bd9e3112dc4372f6f3.vehicle',
      'namespace' => 'discuss',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d5d64b171dd7abe11abefcf58da5933',
      'native_key' => 'discuss.solr.ssl_key',
      'filename' => 'modSystemSetting/c4132b626e8943b388af22d6220be7f0.vehicle',
      'namespace' => 'discuss',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51910692e50d9213b4ad0efd65a9f4b5',
      'native_key' => 'discuss.solr.ssl_keypassword',
      'filename' => 'modSystemSetting/8274672c390903c70682bbcfe3f1ee84.vehicle',
      'namespace' => 'discuss',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b114e74a9ddd6e280d62925f15e413cd',
      'native_key' => 'discuss.solr.ssl_cainfo',
      'filename' => 'modSystemSetting/3e2b18487f693e24c44a002a68d01aa4.vehicle',
      'namespace' => 'discuss',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43cd212690f1b31f96d7fcfc76748243',
      'native_key' => 'discuss.solr.ssl_capath',
      'filename' => 'modSystemSetting/65732301a16a1b66c473d998b1b07108.vehicle',
      'namespace' => 'discuss',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a71e520618a58b23e9cc2bb1470dec49',
      'native_key' => 'discuss.solr.proxy_host',
      'filename' => 'modSystemSetting/e0133acc993c3e835dd856319d614e81.vehicle',
      'namespace' => 'discuss',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73487e90b5f1133b0649b16ff96e2db5',
      'native_key' => 'discuss.solr.proxy_port',
      'filename' => 'modSystemSetting/b4a4ff87aaf49fa8b822bc1d3d8c58e9.vehicle',
      'namespace' => 'discuss',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea876a8893f6a13955429e7512967d62',
      'native_key' => 'discuss.solr.proxy_username',
      'filename' => 'modSystemSetting/a3ee825933e0799202ac8893404a82cb.vehicle',
      'namespace' => 'discuss',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cea487baab2d2b538ef2f10a53fc0f0a',
      'native_key' => 'discuss.solr.proxy_password',
      'filename' => 'modSystemSetting/7a6a760b36e3e130564bb644291d2c86.vehicle',
      'namespace' => 'discuss',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50d0e7c35680238c5ef6d20d98fa3149',
      'native_key' => 'discuss.post_excerpt_length',
      'filename' => 'modSystemSetting/0059b600a8c73768bd741fe205ebf1cb.vehicle',
      'namespace' => 'discuss',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f35a113097777bcf2d9078fb03487942',
      'native_key' => 'discuss.session_ttl',
      'filename' => 'modSystemSetting/3571c05e6f169e8aef82a0759f1f709d.vehicle',
      'namespace' => 'discuss',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86fa3ed3b1b9c881868315bcc4c7255e',
      'native_key' => 'discuss.strip_remaining_bbcode',
      'filename' => 'modSystemSetting/943cd0d054ac563939f500d3bf36b209.vehicle',
      'namespace' => 'discuss',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'f750c3cb3a3b4e735185df79dbceeb22',
      'native_key' => NULL,
      'filename' => 'modUserGroup/89a0e68310b9ea97fbe55e0eb5fe8982.vehicle',
      'namespace' => 'discuss',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '09437906fec2cb267cdce7f26bec8c68',
      'native_key' => NULL,
      'filename' => 'modUserGroup/e32ac48170f06d14ae591d7a17dd9453.vehicle',
      'namespace' => 'discuss',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bd275eb5b010481864a0fdf47e8e43f2',
      'native_key' => 'OnDiscussAttachmentVerify',
      'filename' => 'modEvent/f18a91e71f9c27446d721d964ec1f5fb.vehicle',
      'namespace' => 'discuss',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '04b685c400aedc13d16ca0269167d338',
      'native_key' => 'OnDiscussBeforePostSave',
      'filename' => 'modEvent/51d349d8f51c6761ee6756a694b3e651.vehicle',
      'namespace' => 'discuss',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17410f32db59070e552bf29121310e85',
      'native_key' => 'OnDiscussPostBeforeRemove',
      'filename' => 'modEvent/c12c5a2485e41466800d32810a99b805.vehicle',
      'namespace' => 'discuss',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f185da1075cfc33600dcc50757114f62',
      'native_key' => 'OnDiscussPostBeforeRender',
      'filename' => 'modEvent/e9c8bcc7dced702f38683fa297022b45.vehicle',
      'namespace' => 'discuss',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cc2e1323a1b50383f90f3bc6d13b9d25',
      'native_key' => 'OnDiscussPostCustomParser',
      'filename' => 'modEvent/2ddb54e2f2c7b6c99dc7e9f8d336809f.vehicle',
      'namespace' => 'discuss',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2179ebd1832d1ab9086983aeabe8391c',
      'native_key' => 'OnDiscussPostFetchContent',
      'filename' => 'modEvent/619b425db651d646bd909395828ef37d.vehicle',
      'namespace' => 'discuss',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a3d57f64747cb4fe8ebfb579a9a0ed63',
      'native_key' => 'OnDiscussPostRemove',
      'filename' => 'modEvent/bf4ad44f8e08aaa22afc15ccfeb1da5f.vehicle',
      'namespace' => 'discuss',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ec4e0ffc48a30198c56f10fb7f7622e',
      'native_key' => 'OnDiscussPostSave',
      'filename' => 'modEvent/a4352b7c6a3cd190eefc46d677934647.vehicle',
      'namespace' => 'discuss',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c3a851cd540512352f16257a1bdc155',
      'native_key' => 'OnDiscussBeforeBanUser',
      'filename' => 'modEvent/6a8fea0620346c9928fd167c9a1f17a1.vehicle',
      'namespace' => 'discuss',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d6617756170a7d18fd31245ef3b9422',
      'native_key' => 'OnDiscussBanUser',
      'filename' => 'modEvent/86e4ad257a3c0e8d1aa0021d1a8e28d7.vehicle',
      'namespace' => 'discuss',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '054d914f3d3e42db8dc00455de956940',
      'native_key' => 'OnDiscussRenderHome',
      'filename' => 'modEvent/70b207f1f91f5efbc58bdd54e2d50142.vehicle',
      'namespace' => 'discuss',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a1e5f514a9286b51891bc09c72924a6',
      'native_key' => 'OnDiscussRenderBoard',
      'filename' => 'modEvent/a57198ff294156c5c1241c03afc6f8f2.vehicle',
      'namespace' => 'discuss',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8bc9a5afdd2d1bd57dadcc2108524cd2',
      'native_key' => 'OnDiscussRenderThread',
      'filename' => 'modEvent/e79eee9d866566348a17f1dc34006bff.vehicle',
      'namespace' => 'discuss',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '48357856db65d977598ee6d8fa9b2346',
      'native_key' => 'OnDiscussBeforeMarkAsAnswer',
      'filename' => 'modEvent/e4f8da37d991aa043462ecc1fe8fd4dc.vehicle',
      'namespace' => 'discuss',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c54b1d09055044af9633f02c4150565',
      'native_key' => 'OnDiscussBeforeUnmarkAsAnswer',
      'filename' => 'modEvent/7c94ecd0ac9180d278061d23e71a113c.vehicle',
      'namespace' => 'discuss',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c45ccb5ab4e4b50f34b8ca319d958380',
      'native_key' => 'OnDiscussMarkAsAnswer',
      'filename' => 'modEvent/a5f77c9d6bdfe2b1a4076cd543441070.vehicle',
      'namespace' => 'discuss',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94f307dcbc8e266f6f964d082e56f966',
      'native_key' => 'OnDiscussUnmarkAsAnswer',
      'filename' => 'modEvent/0eee874a234c7a7f2718fa8802784eaf.vehicle',
      'namespace' => 'discuss',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '570cf21b9580523b03710f294840a7f5',
      'native_key' => 'discuss',
      'filename' => 'modMenu/88006bf94826396872b293e3fd259656.vehicle',
      'namespace' => 'discuss',
    ),
  ),
);