<?php
/**
 * @package discuss
 * @subpackage mysql
 */
$xpdo_meta_map['disThreadDiscussion']= array (
  'package' => 'discuss',
  'version' => '1.1',
  'extends' => 'disThread',
  'fields' => 
  array (
  ),
  'fieldMeta' => 
  array (
  ),
);
