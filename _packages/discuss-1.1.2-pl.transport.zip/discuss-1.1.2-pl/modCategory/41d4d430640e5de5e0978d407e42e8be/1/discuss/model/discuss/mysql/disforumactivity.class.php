<?php
/**
 * @package discuss
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/disforumactivity.class.php');
/**
 * @package discuss
 * @subpackage mysql
 */
class disForumActivity_mysql extends disForumActivity {}